#include "Window.h"

Window::Window(int WIDTH, int HEIGHT, const char* TITLE, bool fullscreen)
{
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	InitializeWindow(WIDTH, HEIGHT, TITLE, fullscreen);

	// GLEW: initialize
	// ----------------
	// Note: if using GLEW version 1.13 or earlier
	glewExperimental = GL_TRUE;
	GLenum GlewInitResult = glewInit();


	if (GlewInitResult != GLEW_OK)
	{
		std::cerr << glewGetErrorString(GlewInitResult) << " GLEW error" << std::endl;
	}
	else
	{
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	}
}

bool Window::InitializeWindow(int WIDTH, int HEIGHT, const char* TITLE, bool fullscreen)
{
	this->monitor = nullptr;

	if (fullscreen)
	{
		this->monitor = glfwGetPrimaryMonitor();

		if (this->monitor == NULL)
		{
			std::cout << "could not find primary monitor, quitting";
			this->windowInitialized = false;
			return false;
		}
	}

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// GLFW: window creation
	// ---------------------
	this->window = glfwCreateWindow(WIDTH, HEIGHT, TITLE, this->monitor, NULL);
	if (this->window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		this->windowInitialized = false;
		return false;
	}
	glfwMakeContextCurrent(this->window);
	glfwSetFramebufferSizeCallback(this->window, resizeWindowCallback);
	glfwSetCursorPosCallback(window, mousePositionCallback);
	glfwSetScrollCallback(window, mouseScrollCallback);
	glfwSetMouseButtonCallback(window, mouseButtonCallback);
	glfwSetKeyCallback(window, keyCallback);
	glfwSetWindowUserPointer(window, this);
	this->windowInitialized = true;
	return true;
}

void Window::resizeWindowCallback(GLFWwindow* window, int WIDTH, int HEIGHT)
{
	glViewport(0, 0, WIDTH, HEIGHT);
}

const GLFWvidmode* Window::getWidthHeightStruct()
{
	if (this->monitor == nullptr)
		this->monitor = glfwGetPrimaryMonitor();
	const GLFWvidmode* windowDetails = glfwGetVideoMode(this->monitor);
	return windowDetails;
}

Window::~Window()
{
	glfwTerminate();
}

void Window::setColor(float R, float G, float B, float A)
{
	glClearColor(R, G, B, A);
}

void Window::enable(GLbitfield field)
{
	glEnable(field);
}

void Window::processInput()
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, true);
	}
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
	{
		camera->goForward();
	}
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
	{
		camera->goBackward();
	}
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
	{
		camera->goRight();
	}
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
	{
		camera->goLeft();
	}
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
	{
		camera->goDown();
	}
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
	{
		camera->goUp();
	}
}

void Window::clear(GLbitfield field)
{
	glClear(field);
}

void Window::pollEvents()
{
	glfwPollEvents();
}

int Window::getMaxHeight()
{
	return getWidthHeightStruct()->height;
}

int Window::getMaxWidth()
{
	return getWidthHeightStruct()->width;
}

void Window::mousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
	Window* currentWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));
	Camera* camera = currentWindow->getCamera();
	if (camera->getFirstMouseMoveEvent())
	{
		camera->setLastX(xpos);
		camera->setLastY(ypos);
		camera->setFirstMouseMoveEvent(false);
	}

	float xoffset = xpos - camera->getLastX();
	float yoffset = camera->getLastY() - ypos;

	camera->setLastX(xpos);
	camera->setLastY(ypos);

	camera->look(xoffset, yoffset);
}

void Window::mouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
	Window* currentWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));
	Camera* camera = currentWindow->getCamera();
	camera->changeZoom(yoffset);
}

void Window::mouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
	switch (button)
	{
	case GLFW_MOUSE_BUTTON_LEFT:
	{
		if (action == GLFW_PRESS)
			std::cout << "Left mouse button pressed" << std::endl;
		else
			std::cout << "Left mouse button released" << std::endl;
	}
	break;

	case GLFW_MOUSE_BUTTON_MIDDLE:
	{
		if (action == GLFW_PRESS)
			std::cout << "Middle mouse button pressed" << std::endl;
		else
			std::cout << "Middle mouse button released" << std::endl;
	}
	break;

	case GLFW_MOUSE_BUTTON_RIGHT:
	{
		if (action == GLFW_PRESS)
			std::cout << "Right mouse button pressed" << std::endl;
		else
			std::cout << "Right mouse button released" << std::endl;
	}
	break;

	default:
		std::cout << "Unhandled mouse button event" << std::endl;
		break;
	}
}

void Window::keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	Window* currentWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));
	Camera* camera = currentWindow->getCamera();
	if (key == GLFW_KEY_P && action == GLFW_PRESS)
	{
		camera->ToggleProjection();
	}
}