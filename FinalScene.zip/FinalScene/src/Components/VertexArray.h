#pragma once
#include <src/Components/VertexLayout.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

class VertexArray
{
	// private members
private:
	GLuint vertexArray;
	VertexLayout layout;
	//public methods
public:
	// creates the vertex array in opengl
	VertexArray();
	// deletes the vertex array in opengl
	~VertexArray();
	// binds the vertex array in opengl
	void Bind();
	// unbinds the vertex array from opengl
	void Unbind();
	//
	void PushLayout(unsigned int num);
	// returns the id of the vertex array
	GLuint GetVertexArray() { return this->vertexArray; };
};

