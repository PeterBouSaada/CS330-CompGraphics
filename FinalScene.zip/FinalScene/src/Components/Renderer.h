#pragma once
#include <src/Components/VertexArray.h>
#include <src/Components/VertexBuffer.h>
#include <src/Components/IndexBuffer.h>
#include <src/Components/ShaderProgram.h>
#include <src/Components/Window.h>
#include <src/Math/ModelMatrix.h>
#include <src/Math/ViewMatrix.h>
#include <src/Math/ProjectionMatrix.h>
#include <src/Shapes/Shape.h>
#include <src/Shapes/RenderObject.h>
#include <src/Components/Light.h>
#include <vector>

class Renderer
{
	// private members
private:
	std::vector<RenderObject*> renderObjects;
	std::vector<Light*> lights;
	ShaderProgram* shader;
	int WIDTH;
	int HEIGHT;

	// public methods
public:
	/*	
	 *	RENDERER INITIALIZATION
	 *	- this is where a lot of the abstraction is happening.
	 *	- everytime an object is created, memory is allocated for it through opengl immediately
	 *	however it is not bound to opengl to be modified until the Bind() method is called on that object.
	 * 
	 *	Initialize our renderer
	 *	create the vertex array, vertex buffer, and index buffer
	 *  assign the vertex data to the vertex buffer
	 *  assign the index data tot the index buffer
	 *  set the correct layout for the vertex data (position = 3, color = 4)
	 *	initialize all our members
	 */
	Renderer(std::vector<RenderObject*> renderObjects, std::vector<Light*> lights, const char* vertexShaderSource, const char* fragmentShaderSource, int WIDTH, int HEIGHT);
	//	destroy the reference to the shader.
	~Renderer();
	/*
	 *	RENDER
	 *	- this is where the GL draw call happens.
	 *	- the MVP matrices are calculated in here, in the future, we want them to change at runtime.
	 * 
	 *	clear the window buffer, enable GL_DEPTH_TEST, set the color to black
	 *	create the MVP matrices with the hard coded values.
	 *	bind the shader, and the vertex array.
	 *	execute draw call on opengl
	 *	unbind vertex array
	 *	swap buffers every frame.
	 * 
	 */
	const void Render(Window* window, Camera* camera);
};

