#include "Renderer.h"
#include <src/Shapes/Cylinder.h>

Renderer::Renderer(std::vector<RenderObject*> renderObjects, std::vector<Light*> lights, const char* vertexShaderSource, const char* fragmentShaderSource, int WIDTH, int HEIGHT)
{
	this->renderObjects = renderObjects;
	this->lights = lights;

	shader = new ShaderProgram(vertexShaderSource, fragmentShaderSource);

	for (Light* light : lights)
	{
		light->setShader(shader->GetShader());
	}

	for (int j = 0; j < renderObjects.size(); j++)
	{
		std::vector<Shape*> shapes = renderObjects[j]->getShapes();
		for (int i = 0; i < shapes.size(); i++)
		{

			VertexArray* va = new VertexArray();
			va->Bind();
			renderObjects[j]->setVAO(va);

			Shape* s = shapes[i];

			VertexBuffer* vb = new VertexBuffer(GL_ARRAY_BUFFER, sizeof(float) * s->getVerticesArraySize(), s->getVertices(), GL_STATIC_DRAW);
			renderObjects[j]->setVBO(vb);


			IndexBuffer* ib = new IndexBuffer(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * s->getIndicesArraySize(), s->getIndices(), GL_STATIC_DRAW);
			renderObjects[j]->setIBO(ib);

			va->PushLayout(3);
			va->PushLayout(4);
			va->PushLayout(2);
			va->PushLayout(3);
		}
	}

	glm::vec2 UVScale(5.0f, 5.0f);

	glUniform1i(glGetUniformLocation(shader->GetShader(), "uTextureBase"), 0);
	glUniform1i(glGetUniformLocation(shader->GetShader(), "uTextureExtra"), 1);

	GLint UVScaleLoc = glGetUniformLocation(shader->GetShader(), "uvScale");
	glUniform2fv(UVScaleLoc, 1, glm::value_ptr(UVScale));

	this->WIDTH = WIDTH;
	this->HEIGHT = HEIGHT;
}

Renderer::~Renderer()
{
	shader->~ShaderProgram();
}

const void Renderer::Render(Window* window, Camera* camera)
{
	glEnable(GL_DEPTH_TEST);

	// Clear the background
	window->setColor(0.1f, 0.1f, 0.1f, 1.0f);
	window->clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// initialize the MVP matrices (hard coded values for now)
	GLuint shaderProgramId = shader->GetShader();

	ModelMatrix parent("parent", shader->GetShader());
	ModelMatrix model("model", shader->GetShader());
	ViewMatrix view("view", shaderProgramId);
	ProjectionMatrix projection("projection", shaderProgramId);

	if (camera->shouldRecalculatePosition())
	{
		view.buildMatrix(camera->getPosition(), camera->getFront(), camera->getUp());
		if (camera->getIsPerspective())
			projection.buildMatrix(glm::radians(camera->getZoom()), WIDTH / HEIGHT, 0.1f, 100.0f);
		else
			projection.buildMatrix(-20.0f, 20.0f, -20.0f, 20.0f, 0.1f, 100.0f);
	}

	for (Light* light : lights)
	{
		light->onRender();
	}

	const glm::vec3 cameraPosition = camera->getPosition();
	glUniform3f(glGetUniformLocation(shader->GetShader(), "u_viewPosition"), cameraPosition.x, cameraPosition.y, cameraPosition.z);

	for (int j = 0; j < renderObjects.size(); j++)
	{
		std::vector<Shape*> shapes = renderObjects[j]->getShapes();
		parent.buildMatrix(renderObjects[j]->getScale(), renderObjects[j]->getAngle(), renderObjects[j]->getRotation(), renderObjects[j]->getTransform());
		for (int i = 0; i < shapes.size(); i++)
		{

			shader->Bind();
			Shape* s = shapes[i];
			model.buildMatrix(s->getScale(), s->getAngle(), s->getRotation(), s->getTransform());
			model.setMatrix(parent * model);

			// Activate the VBOs contained within the mesh's VAO
			renderObjects[j]->getVAO()->Bind();

			GLuint texturedLoc = glGetUniformLocation(shader->GetShader(), "textured");
			glUniform1i(texturedLoc, s->IsTextured());

			GLuint multipleTexturesLoc = glGetUniformLocation(shader->GetShader(), "multipleTextures");
			glUniform1i(multipleTexturesLoc, s->multipleTextures());

			if (s->IsTextured() || s->multipleTextures())
			{
				for (Texture* tex : s->getTexture())
				{
					tex->Bind();
				}
			}

			GLuint isLitLoc = glGetUniformLocation(shader->GetShader(), "u_isLit");
			glUniform1i(isLitLoc, s->getIsLit());

			glDrawElements(GL_TRIANGLES, s->getIndicesArraySize(), GL_UNSIGNED_SHORT, NULL); // Draws the triangle

			renderObjects[j]->getVAO()->Unbind();
		}
	}

	// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
	glfwSwapBuffers(window->getWindow());
}
