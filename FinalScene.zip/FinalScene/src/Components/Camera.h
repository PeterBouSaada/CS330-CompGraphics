#pragma once
#include <glm/glm.hpp>

class Camera
{
private:
	glm::vec3 position;
	glm::vec3 front;
	glm::vec3 up;
	glm::vec3 right;
	bool recalcPosition = true;
	bool firstMouseMoveEvent = true;
	bool isPerspective = true;
	bool canCallToggle = true;
	float zoom = 45.0f;
	float offset = 0.0f;
	float speed = 5.0f;
	float mouseSensitivity = 0.1f;
	float yaw = -90.0f;
	float pitch = 0.0f;
	float lastX = 0.0f;
	float lastY = 0.0f;
	void clampZoom() { if (zoom > 45.0f) { zoom = 45.0f; } if (zoom < 1.0f) { zoom = 1.0f; } }
public:
	Camera() : position(glm::vec3(0.0f, 5.0f, 20.0f)), front(glm::vec3(0.0f, 0.0f, -1.0f)), up(glm::vec3(0.0f, 1.0f, 0.0f)), right(glm::normalize(glm::cross(front, up))) {}
	~Camera() {}
	glm::vec3 getPosition() { recalcPosition = false; return position; };
	float getZoom() { recalcPosition = true; return zoom; }
	float getMouseSensitivity() { recalcPosition = true; return mouseSensitivity; }
	glm::vec3 getFront() { return front; }
	glm::vec3 getUp() { return up; }
	bool shouldRecalculatePosition() { return recalcPosition; }
	void calculateOffset(float deltaTime) { offset = speed * deltaTime; }
	float getLastX() { return lastX; }
	float getLastY() { return lastY; }
	void setLastX(float x) { lastX = x; }
	void setLastY(float y) { lastY = y; }
	bool getIsPerspective() { return isPerspective; }
	void ToggleProjection() { isPerspective = !isPerspective; recalcPosition = true; }
	bool getFirstMouseMoveEvent() { return firstMouseMoveEvent; }
	void setFirstMouseMoveEvent(bool b) { firstMouseMoveEvent = b; }
	void setPosition(glm::vec3 pos) { position = pos; recalcPosition = true; }
	void setPosX(float x) { position.x = x; recalcPosition = true; }
	void setPosY(float y) { position.y = y; recalcPosition = true; }
	void setPosZ(float z) { position.y = z; recalcPosition = true; }
	void goForward() { position += offset * front; recalcPosition = true; }
	void goBackward() { position -= offset * front; recalcPosition = true; }
	void goRight() { position += right * offset; recalcPosition = true; }
	void goLeft() { position -= right * offset; recalcPosition = true; }
	void goUp() { position += offset * up; recalcPosition = true; }
	void goDown() { position -= offset * up; recalcPosition = true; }
	void changeZoom(float yoffset) { zoom -= (float) yoffset; clampZoom(); recalcPosition = true; }
	void look(float x, float y) {
		x *= mouseSensitivity;
		y *= mouseSensitivity;

		yaw += x;
		pitch += y;

		if (pitch > 89.0f)
			pitch = 89.0f;
		if (pitch < -89.0f)
			pitch = -89.0f;

		glm::vec3 tempFront;
		tempFront.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
		tempFront.y = sin(glm::radians(pitch));
		tempFront.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
		front = glm::normalize(tempFront);

		right = glm::normalize(glm::cross(front, glm::vec3(0.0f, 1.0f, 0.0f)));
		up = glm::normalize(glm::cross(right, front));
		recalcPosition = true;
	}
};

