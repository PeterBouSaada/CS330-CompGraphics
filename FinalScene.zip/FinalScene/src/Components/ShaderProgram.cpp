#include "ShaderProgram.h"

ShaderProgram::ShaderProgram()
{
}

ShaderProgram::ShaderProgram(const char* vertexSource, const char* fragmentSource)
{

    // Create a Shader program object.
    shader = glCreateProgram();

    createShader(vertexSource, GL_VERTEX_SHADER);
    createShader(fragmentSource, GL_FRAGMENT_SHADER);

    Link();
    Bind();
}

ShaderProgram::~ShaderProgram()
{
    glDeleteProgram(shader);
}

bool ShaderProgram::Link()
{
    int success = 0;
    char infoLog[512];

    glLinkProgram(shader);   // links the shader program
    
    // check for linking errors
    glGetProgramiv(shader, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(shader, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }
    return true;
}

void ShaderProgram::Bind()
{
    glUseProgram(shader);
}

void ShaderProgram::Unbind()
{
    glUseProgram(0);
}

bool ShaderProgram::createShader(const char* source, unsigned int type)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];
    const char* shaderName = "";

    if (type == GL_VERTEX_SHADER)
    {
        shaderName = "VERTEX";
    }
    else if (type == GL_FRAGMENT_SHADER)
    {
        shaderName = "FRAGMENT";
    }

    // Create the vertex and fragment shader objects
    GLuint shaderId = glCreateShader(type);
    
    // Retrive the shader source
    glShaderSource(shaderId, 1, &source, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(shaderId); // compile the vertex shader
    
                                     // check for shader compile errors
    glGetShaderiv(shaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(shaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::" << shaderName << "::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(shader, shaderId);

    return true;

}