#include "IndexBuffer.h"

IndexBuffer::IndexBuffer(unsigned int type, int size, GLushort* indices, int drawType)
{
	this->type = type;
	glGenBuffers(1, &indexBuffer);
	Bind();
	AddBufferData(size, indices, drawType);
}

IndexBuffer::~IndexBuffer()
{
	glDeleteBuffers(1, &indexBuffer);
}

void IndexBuffer::Bind()
{
	glBindBuffer(type, indexBuffer);
}

void IndexBuffer::Unbind()
{
	glBindBuffer(type, 0);
}

void IndexBuffer::AddBufferData(int size, GLushort* indices, int drawType)
{
	glBufferData(type, size, indices, drawType);
}
