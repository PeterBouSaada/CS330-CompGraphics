#include "Light.h"

void Light::onRender()
{
	glUniform3f(glGetUniformLocation(this->shader, std::string("u_lightColor" + lightNum).c_str()), color.x, color.y, color.z);
	glUniform3f(glGetUniformLocation(this->shader, std::string("u_lightPos" + lightNum).c_str()), transform.x, transform.y, transform.z);
	glUniform1f(glGetUniformLocation(this->shader, std::string("u_specularIntensity" + lightNum).c_str()), specularIntensity);
	glUniform1f(glGetUniformLocation(this->shader, std::string("u_highlightSize" + lightNum).c_str()), highlightSize);
}