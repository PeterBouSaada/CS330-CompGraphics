#pragma once
#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

class ShaderProgram
{
	// private methods and members
private:
	bool createShader(const char* source, unsigned int type);
	GLuint shader;

	// public methods
public:
	// does nothing
	ShaderProgram();
	// compiles the vertex and fragment shaders and sends the programs to the gpu
	ShaderProgram(const char* vertexSource, const char* fragmentSource);
	// destroys the shader
	~ShaderProgram();
	// returns the id of the shader
	GLuint GetShader() { return shader; }
	// links the shader
	bool Link();
	// binds the shader to be used, using glUseProgram
	void Bind();
	// unbinds the shader.
	void Unbind();
};

