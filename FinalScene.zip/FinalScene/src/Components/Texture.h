#pragma once
#include <vendor/stb_image/stb_image.h>
#include <iostream>
#include <GL/glew.h>

class Texture
{
private:
	int m_width;
	int m_height;
	int m_channels;
	unsigned short slot = 0;
	GLuint m_textureID;
	bool Initialize(const std::string& filename);
public:
	Texture(const std::string& filename, unsigned short slot = 0);
	~Texture();
	void Bind();
	void Unbind();
};

