#include "VertexLayout.h"

void VertexLayout::PushLayout(unsigned int num)
{
	layout.push_back(num);
	UpdateLayout();
}

void VertexLayout::UpdateLayout()
{
	calculateStride();
	unsigned int last = 0;
	for (int i = 0; i < layout.size(); i++)
	{
		char* lastPtr = (char*)(sizeof(float) * last);
		glDisableVertexAttribArray(i);
		glVertexAttribPointer(i, layout[i], GL_FLOAT, GL_FALSE, stride, lastPtr);
		glEnableVertexAttribArray(i);
		last += layout[i];
	}
}

void VertexLayout::calculateStride()
{
	stride = 0;
	for (unsigned int i : layout)
	{
		stride += sizeof(float) * i;
	}
}