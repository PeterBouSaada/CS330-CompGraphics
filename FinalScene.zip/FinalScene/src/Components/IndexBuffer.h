#pragma once
#include <GL/glew.h>
#include <GLFW/glfw3.h>

class IndexBuffer
{
	// private members
private:
	GLuint indexBuffer;
	unsigned int type;

	//public methods
public:
	// creates an index buffer in opengl
	IndexBuffer(unsigned int type, int size, GLushort* indices, int drawType);
	// deletes the existing index buffer from opengl
	~IndexBuffer();
	// Binds the index buffer using the type of buffer
	void Bind();
	// Unbinds the index buffer using the type of buffer
	void Unbind();
	// Adds buffer data to the allocated memory
	void AddBufferData(int size, GLushort* indices, int drawType);
	// returns the id of the index buffer
	GLuint GetVertexBuffer() { return this->indexBuffer; }
	// get the buffer type
	unsigned int getType() { return type; }
};