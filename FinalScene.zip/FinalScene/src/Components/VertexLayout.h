#pragma once
#include <gl/glew.h>
#include <vector>

class VertexLayout
{
private:
	std::vector<unsigned int> layout;
	int stride = 0;
	void calculateStride();
public:
	VertexLayout() {};
	~VertexLayout() {};
	void PushLayout(unsigned int num);
	void UpdateLayout();
};

