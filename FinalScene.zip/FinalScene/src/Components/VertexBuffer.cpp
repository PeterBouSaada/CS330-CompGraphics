#include "VertexBuffer.h"
#include <iostream>

VertexBuffer::VertexBuffer(unsigned int type, int size, GLfloat* vertices, int drawType)
{
	this->type = type;
	glGenBuffers(1, &vertexBuffer);
	Bind();
	AddBufferData(size, vertices, drawType);
}

VertexBuffer::~VertexBuffer()
{
	glDeleteBuffers(1, &vertexBuffer);
}

void VertexBuffer::Bind()
{
	glBindBuffer(type, vertexBuffer);
}

void VertexBuffer::Unbind()
{
	glBindBuffer(type, 0);
}

void VertexBuffer::AddBufferData(int size, GLfloat* vertices, int drawType)
{
	glBufferData(type, size, vertices, drawType);
}
