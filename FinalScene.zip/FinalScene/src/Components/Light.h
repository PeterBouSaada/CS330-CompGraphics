#pragma once

#include <iostream>
#include <glm/glm.hpp>
#include <GL/glew.h>
#include <src/Components/Texture.h>
#include <src/Components/ShaderProgram.h>
#include <vector>

class Light
{
protected:
	glm::vec3 transform;
	glm::vec3 rotation;
	float angle;
	glm::vec3 scale;
	glm::vec3 color;
	GLuint shader;
	float specularIntensity = 0.8f;
	float highlightSize = 16.0f;
	std::string lightNum;
public:
	Light() : transform(glm::vec3(0)), rotation(glm::vec3(1.0, 0.0, 0.0)), scale(glm::vec3(1.0)), angle(0), shader(0), color(glm::vec3(1.0f)) {}
	Light(glm::vec3 transform, glm::vec3 rotation, glm::vec3 scale, glm::vec3 color) : transform(transform), rotation(rotation), scale(scale), color(color), angle(0), shader(0) {};
	~Light() {}
	virtual void onRender();
	void setColor(glm::vec3 color) { this->color = color; }
	void setShader(GLuint shader) { this->shader = shader; };
	void setLightNum(std::string n) { lightNum = n; }
	glm::vec3 getTransform() { return transform; }
	glm::vec3 getRotation() { return rotation; }
	glm::vec3 getScale() { return scale; }
	float getAngle() { return angle; }
	float getTransformX() { return transform.x; }
	float getTransformY() { return transform.y; }
	float getTransformZ() { return transform.z; }
	float getRotationX() { return rotation.x; }
	float getRotationY() { return rotation.y; }
	float getRotationZ() { return rotation.z; }
	float getScaleX() { return scale.x; }
	float getScaleY() { return scale.y; }
	float getScaleZ() { return scale.z; }
	void setAngle(float w) { angle = w; }
	void setTransformX(float x) { transform.x = x; }
	void setTransformY(float y) { transform.y = y; }
	void setTransformZ(float z) { transform.z = z; }
	void setRotationX(float x) { rotation.x = x; }
	void setRotationY(float y) { rotation.y = y; }
	void setRotationZ(float z) { rotation.z = z; }
	void setScaleX(float x) { scale.x = x; }
	void setScaleY(float y) { scale.y = y; }
	void setScaleZ(float z) { scale.z = z; }
	void setScale(glm::vec3 s) { scale = s; }
	void setRotation(float a, glm::vec3 r) { angle = a; rotation = r; }
	void setTransform(glm::vec3 t) { transform = t; }
	void setSpecularIntensity(float f) { specularIntensity = f; }
	void setHightlightSize(float f) { highlightSize = f; }
	float getSpecularIntensity() { return specularIntensity; }
	float getHighlightSize() { return highlightSize; }
};

