#include "VertexArray.h"
#include <iostream>

VertexArray::VertexArray()
{
	glGenVertexArrays(1, &vertexArray);
}

VertexArray::~VertexArray()
{
	glDeleteVertexArrays(1, &vertexArray);
}

void VertexArray::Bind()
{
	glBindVertexArray(vertexArray);
}

void VertexArray::Unbind()
{
	glBindVertexArray(0);
}

void VertexArray::PushLayout(unsigned int num)
{
	layout.PushLayout(num);
}
