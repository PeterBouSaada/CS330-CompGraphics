#pragma once
#include <iostream>
#include <cstdlib>
#include <memory>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include "Camera.h"

class Window
{
private:
	GLFWwindow* window = nullptr;
	GLFWmonitor* monitor = nullptr;
	Camera* camera = nullptr;
	bool windowInitialized = false;
private:
	// Initializes glfw so we can use glfw functions
	bool InitializeWindow(int WIDTH, int HEIGHT, const char* TITLE, bool fullscreen);
	void static resizeWindowCallback(GLFWwindow* window, int width, int height);
	const GLFWvidmode* getWidthHeightStruct();

	// public methods
public:
	// constructor, calls InitializeGLFW method
	Window(int WIDTH, int HEIGHT, const char* TITLE = "", bool fullscreen = false);
	// destructor
	~Window();
	// returns the private property window
	GLFWwindow* getWindow() { return this->window; };
	// returns the camera
	Camera* getCamera() { return camera; }
	// returns the status of the window
	bool initialized() { return this->windowInitialized; };
	// gives the window object a reference to the camera object
	void bindCamera(Camera* cam) { camera = cam; }
	// changes the color of the screen
	void setColor(float R, float G, float B, float A);
	// enable a flag
	void enable(GLbitfield field);
	// process input
	void processInput();
	// clears the screen
	void clear(GLbitfield field);
	// polls for events (called every frame)
	void pollEvents();
	// returns primary monitors height
	int getMaxHeight();
	// returns primary monitors width
	int getMaxWidth();
	// Callbacks
	static void mousePositionCallback(GLFWwindow* window, double xpos, double ypos);
	static void mouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
	static void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
	static void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods);
};

