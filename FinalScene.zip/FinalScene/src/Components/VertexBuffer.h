#pragma once
#include <GL/glew.h>
#include <GLFW/glfw3.h>

class VertexBuffer
{
	// private members
private:
	GLuint vertexBuffer;
	unsigned int type;

	// public methods
public:
	// creates the Vertex buffer in opengl
	VertexBuffer(unsigned int type, int size, GLfloat* vertices, int drawType);
	// deletes the Vertex buffer from opengl
	~VertexBuffer();
	// Binds the vertex buffer using the type of buffer
	void Bind();
	// Unbinds the vertex buffer using the type of buffer
	void Unbind();
	// Adds buffer data to the bound vertex buffer
	void AddBufferData(int size, GLfloat* vertices, int drawType);
	// returns the id of the vertex buffer
	GLuint GetVertexBuffer() { return this->vertexBuffer; };
	// get the type
	unsigned int getType() { return type; }
};

