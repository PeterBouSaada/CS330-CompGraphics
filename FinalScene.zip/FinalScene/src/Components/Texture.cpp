#include "Texture.h"

Texture::Texture(const std::string& filename, unsigned short slot)
{
	this->slot = slot;
	if (Initialize(filename))
	{
		std::cout << "Texture - " << filename << " loaded successfully" << std::endl;
	}
}

Texture::~Texture()
{
	glDeleteTextures(1, &m_textureID);
}


bool Texture::Initialize(const std::string& filename)
{
	stbi_set_flip_vertically_on_load(true);
	unsigned char* image = stbi_load(filename.c_str(), &m_width, &m_height, &m_channels, 0);
	if (image)
	{
		glewExperimental = GL_TRUE;
		glGenTextures(1, &m_textureID);
		glBindTexture(GL_TEXTURE_2D, m_textureID);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (m_channels == 3)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, m_width, m_height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		}
		else if (m_channels == 4)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, m_width, m_height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		}
		else
		{
			std::cout << "Texture Constructor: Image format not supported" << std::endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		this->Unbind();
		return true;
	}
	std::cout << "Image not loaded" << std::endl;
	return false;
}

void Texture::Bind()
{
	glActiveTexture(GL_TEXTURE0 + slot);
	glBindTexture(GL_TEXTURE_2D, m_textureID);
}

void Texture::Unbind()
{
	glBindTexture(GL_TEXTURE_2D, 0);
}

