#pragma once

#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source;
#endif

// Vertex Shader Program Source Code
const char* vertexShaderSource = GLSL(460,
	layout(location = 0) in vec3 position;
layout(location = 1) in vec4 color;
layout(location = 2) in vec2 uvCoords;
layout(location = 3) in vec3 normals;

out vec4 vertexColor;
out vec2 vertexTextureCoordinate;
out vec3 v_Normals;
out vec3 v_VertexFragPos;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0);
	v_VertexFragPos = vec3(model * vec4(position, 1.0f));
	vertexColor = color;
	vertexTextureCoordinate = uvCoords;
	v_Normals = mat3(transpose(inverse(model))) * normals;
};
)

// Fragment Shader Program Source Code
const char* fragmentShaderSource = GLSL(460,
	in vec2 vertexTextureCoordinate;

in vec4 vertexColor;
in vec3 v_Normals;
in vec3 v_VertexFragPos;

out vec4 FragColor;

uniform sampler2D uTextureBase;
uniform sampler2D uTextureExtra;

uniform bool multipleTextures;
uniform bool textured;
uniform bool u_isLit;

uniform vec2 uvScale;

uniform vec3 u_lightColor1;
uniform vec3 u_lightPos1;
uniform vec3 u_lightColor2;
uniform vec3 u_lightPos2;
uniform vec3 u_viewPosition;

uniform float u_specularIntensity1;
uniform float u_highlightSize1;
uniform float u_specularIntensity2;
uniform float u_highlightSize2;

void main()
{

	if (textured)
	{
		vec4 objectColor = texture(uTextureBase, vertexTextureCoordinate);
		if (multipleTextures)
		{
			vec4 extraTexture = texture(uTextureExtra, vertexTextureCoordinate);
			if (extraTexture.a != 0.0)
				objectColor = extraTexture;
		}

		if (u_isLit)
		{
			// begin directional light
			// ---------------------------------------------------------------------------
			// calculate ambient lighting
			float ambientStrength1 = 0.1f;
			vec3 ambient1 = ambientStrength1 * u_lightColor1;

			// calculate diffuse
			vec3 norm1 = normalize(v_Normals);
			vec3 lightDirection1 = normalize(-u_lightPos1);
			float impact1 = max(dot(norm1, lightDirection1), 0.0);
			vec3 diffuse1 = impact1 * u_lightColor1;

			// calculate specular lighting
			float specularIntensity1 = u_specularIntensity1;
			float highlightSize1 = u_highlightSize1;
			vec3 viewDir1 = normalize(u_viewPosition - v_VertexFragPos);
			vec3 reflectDir1 = reflect(-lightDirection1, norm1);

			//Calculate specular component.
			float specularComponent1 = pow(max(dot(viewDir1, reflectDir1), 0.0), highlightSize1);
			vec3 specular1 = specularIntensity1 * specularComponent1 * u_lightColor1;
			// end directional light
			// ---------------------------------------------------------------------------

			// begin point light
			// ---------------------------------------------------------------------------
			// calculate ambient lighting
			float ambientStrength2 = 0.2f;
			vec3 ambient2 = ambientStrength2 * u_lightColor2;

			// calculate diffuse
			vec3 norm2 = normalize(v_Normals);
			vec3 lightDirection2 = normalize(u_lightPos2 - v_VertexFragPos);
			float impact2 = max(dot(norm2, lightDirection2), 0.0);
			vec3 diffuse2 = impact2 * u_lightColor2;

			// calculate specular lighting
			float specularIntensity2 = u_specularIntensity2;
			float highlightSize2 = u_highlightSize2;
			vec3 viewDir2 = normalize(u_viewPosition - v_VertexFragPos);
			vec3 reflectDir2 = reflect(-lightDirection2, norm2);

			//Calculate specular component.
			float specularComponent2 = pow(max(dot(viewDir2, reflectDir2), 0.0), highlightSize2);
			vec3 specular2 = specularIntensity2 * specularComponent2 * u_lightColor2;
			// end directional light
			// ---------------------------------------------------------------------------

			// Calculate Phong result.
			objectColor.xyz = (ambient1 + diffuse1 + specular1 + ambient2 + diffuse2 + specular2) * objectColor.xyz;
		}

		FragColor = vec4(objectColor.xyz, 1.0f);
	}
	else
	{
		FragColor = vec4(vertexColor);
	}
};
)