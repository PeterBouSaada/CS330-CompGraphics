#pragma once
#include "Matrix.h"

class ProjectionMatrix : public Matrix
{
	// public methods
public:
	// use the Matrix constructor to create a new matrix in opengl
	ProjectionMatrix(const char* name, GLuint shader) : Matrix(name, shader) {};
	// override the 2 appropriate methods from Matrix
	// for ortho view:
	void buildMatrix(float left, float right, float bottom, float top, float near, float far) override;
	// for perspective view:
	void buildMatrix(float fovy, float aspectRatio, float near, float far) override;
};

