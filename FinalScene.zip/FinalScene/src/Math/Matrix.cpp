#include "Matrix.h"

Matrix::Matrix(const char* name, GLuint shader)
{
	this->shader = shader;
	this->name = name;
	this->matrixLoc = glGetUniformLocation(shader, name);
	matrix = glm::mat4(0);
}

Matrix::~Matrix(){}

void Matrix::Bind()
{
	glUniformMatrix4fv(matrixLoc, 1, GL_FALSE, glm::value_ptr(matrix));
}

