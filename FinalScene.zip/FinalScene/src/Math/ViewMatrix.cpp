#include "ViewMatrix.h"

void ViewMatrix::buildMatrix(glm::vec3 pos, glm::vec3 front, glm::vec3 up)
{
	matrix = glm::lookAt(pos, pos + front, up);
	Bind();
}