#pragma once
#include "Matrix.h"

class ViewMatrix: public Matrix
{
	// public methods
public:
	// use the Matrix constructor to create a new matrix in opengl
	ViewMatrix(const char* name, GLuint shader) : Matrix(name, shader) {};
	// override the appropriate method from Matrix
	void buildMatrix(glm::vec3 pos, glm::vec3 front, glm::vec3 up) override;
};

