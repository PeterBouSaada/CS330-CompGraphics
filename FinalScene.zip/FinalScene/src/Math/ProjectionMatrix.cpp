#include "ProjectionMatrix.h"

void ProjectionMatrix::buildMatrix(float left, float right, float bottom, float top, float near, float far)
{
	matrix = glm::ortho(left, right, bottom, top, near, far);
	Bind();
}

void ProjectionMatrix::buildMatrix(float fovy, float aspectRatio, float near, float far)
{
	matrix = glm::perspective(fovy, aspectRatio, near, far);
	Bind();
}