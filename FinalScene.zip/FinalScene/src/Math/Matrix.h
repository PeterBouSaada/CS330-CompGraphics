#pragma once
#include "../Components/ShaderProgram.h"
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

class Matrix
{
	// protected members
protected: 
	GLuint shader;
	const char* name;
	GLint matrixLoc;
	glm::mat4 matrix;

	//public methods
public:
	// creates a new matrix to be used through shader code using the name
	Matrix(const char* name, GLuint shader);
	// destroys this object
	~Matrix();
	// connects the matrix to the shader Uniform value
	void Bind();
	// operator* overload
	glm::mat4 operator*(const Matrix rhs)
	{
		return matrix * rhs.matrix;
	}
	// set matrix
	void setMatrix(glm::mat4 m)
	{
		matrix = m;
		Bind();
	}
	/* Virtual methods that do not require implementation
	 * Each child of the Matrix class will override the implementation that it requires.
	 * This is done for code clarity.
	 */
	virtual void buildMatrix(glm::vec3 values) {};
	virtual void buildMatrix(glm::vec3 pos, glm::vec3 front, glm::vec3 up) {};
	virtual void buildMatrix(float fovy, float aspectRatio, float near, float far) {};
	virtual void buildMatrix(float left, float right, float bottom, float top, float near, float far) {};
	virtual void buildMatrix(glm::vec3 scale, float angle, glm::vec3 rotate, glm::vec3 translate) {};
};

