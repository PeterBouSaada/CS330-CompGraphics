#pragma once
#include "Matrix.h"
class ModelMatrix: public Matrix
{
	// public methods
public:
	// use the Matrix constructor to create a new matrix in opengl
	ModelMatrix(const char* name, GLuint shader) : Matrix(name, shader) {};
	// override the appropriate buildMatrix method to create a Model matrix
	void buildMatrix(glm::vec3 scale, float angle, glm::vec3 rotate, glm::vec3 translate) override;
};

