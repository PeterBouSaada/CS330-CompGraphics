#include "ModelMatrix.h"

void ModelMatrix::buildMatrix(glm::vec3 scale, float angle, glm::vec3 rotate, glm::vec3 translate)
{
    // 1. Scales the object by 2
    glm::mat4 matScale = glm::scale(scale);
    // 2. Rotates the shape by 15 degrees in the x axis
    glm::mat4 matRotate = glm::rotate(angle, rotate);
    // 3. Places object at the origin
    glm::mat4 matTranslate = glm::translate(translate);

    matrix = matTranslate * matRotate * matScale;
    Bind();
}
