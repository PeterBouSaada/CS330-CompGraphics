#define STB_IMAGE_IMPLEMENTATION

#include "Components/Renderer.h"
#include "Components/Window.h"
#include "Components/Camera.h"
#include "Components/Texture.h"
#include "Components/Light.h"

#include "Shapes/Shape.h"
#include "Shapes/Pyramid.h"
#include "Shapes/Cube.h"
#include "Shapes/Plane.h"

#include <src/Shaders.h>

#include <vector>
#include <src/Shapes/Cylinder.h>

// empty namespace to hold window size and title
namespace STPT {
	int WIDTH = 800;
	int HEIGHT = 600;
	const char* TITLE = "OpenGL Textured Scene | Peter Bou Saada";
}

std::string gTextureDir = "Textures/";

std::string setTexture(std::string filename);

int main(int argc, char* argv[])
{
	// Start glfw and our window
	Window window(STPT::WIDTH, STPT::HEIGHT, STPT::TITLE);
	if (!window.initialized())
		return EXIT_FAILURE;

	Camera camera;
	window.bindCamera(&camera);

	window.setColor(0.1f, 0.1f, 0.1f, 1.0f);

	std::vector<Light*> lights;
	std::vector<Shape*> walletShapes;
	std::vector<Shape*> groundShapes;
	std::vector<Shape*> bookShapes;
	std::vector<Shape*> bottleShapes;
	std::vector<Shape*> penShapes;
	std::vector<Shape*> pyramidShapes;

	std::vector<Texture*> tableTex = {
		new Texture(setTexture("table.jpg"), 0)
	};

	std::vector<Texture*> walletTex1 = {
		new Texture(setTexture("wallet.png"), 0),
	};

	std::vector<Texture*> walletTex2 = {
		new Texture(setTexture("wallet_inside.png"), 0),
	};

	std::vector<Texture*> bookTex = {
		new Texture(setTexture("Book.png"), 0),
	};

	std::vector<Texture*> bottleTex1 = {
		new Texture(setTexture("metal.png"), 0),
	};

	std::vector<Texture*> plastic = {
		new Texture(setTexture("plastic.png"), 0),
	};

	std::vector<Texture*> penTex1 = {
		new Texture(setTexture("pen.png"), 0),
	};

	std::vector<Texture*> penTex3 = {
		new Texture(setTexture("pentip.png"), 0),
	};

	std::vector<Texture*> pyrTex = {
		new Texture(setTexture("glass.png"), 0),
	};

	Plane* table = new Plane(tableTex);
	table->setRotation(glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
	table->setScale(glm::vec3(15.0f, 15.0f, 1.0f));
	table->setTransform(glm::vec3(-7.5f, -0.1f, -7.5f));
	table->setIsLit(true);

	Cube* walletShape1 = new Cube(walletTex1);
	walletShape1->setScale(glm::vec3(2.0f, 0.1f, 2.0f));
	walletShape1->setTransform(glm::vec3(0.0f, 0.3f, 0.0f));

	Cube* walletShape2 = new Cube(walletTex2);
	walletShape2->setScale(glm::vec3(0.1f, 0.4f, 2.0f));
	walletShape2->setTransform(glm::vec3(-1.05f, 0.15f, 0.0f));

	Cube* walletShape3 = new Cube(walletTex2);
	walletShape3->setScale(glm::vec3(2.0f, 0.1f, 2.0f));

	Cube* Book = new Cube(bookTex);
	Book->setScale(glm::vec3(3.0f, 0.2f, 6.0f));

	Cylinder* bottleBottom = new Cylinder(32, bottleTex1);
	bottleBottom->setScale(glm::vec3(1.0f, 1.0f, 3.0f));
	bottleBottom->setRotation(glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));

	Cylinder* bottleTop = new Cylinder(32, plastic);
	bottleTop->setScale(glm::vec3(0.7f, 0.7f, 0.5f));
	bottleTop->setRotation(glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
	bottleTop->setTransform(glm::vec3(0.0f, 1.749f, 0.0f));

	Cylinder* penBottom = new Cylinder(32, penTex1);
	penBottom->setTransform(glm::vec3(0.0f, 0.0f, -0.7f));
	penBottom->setScale(glm::vec3(0.1f, 0.1f, 1.0f));

	Cylinder* penMiddle = new Cylinder(32, plastic);
	penMiddle->setScale(glm::vec3(0.12f, 0.12f, 0.4f));

	Cylinder* penTop = new Cylinder(32, penTex3);
	penTop->setTransform(glm::vec3(0.0f, 0.0f, 0.25f));
	penTop->setScale(glm::vec3(0.1f, 0.1f, 0.1f));

	Pyramid* pyramid = new Pyramid(pyrTex);
	
	groundShapes.push_back(table);
	walletShapes.push_back(walletShape1);
	walletShapes.push_back(walletShape2);
	walletShapes.push_back(walletShape3);
	bookShapes.push_back(Book);
	bottleShapes.push_back(bottleBottom);
	bottleShapes.push_back(bottleTop);
	penShapes.push_back(penBottom);
	penShapes.push_back(penMiddle);
	penShapes.push_back(penTop);
	pyramidShapes.push_back(pyramid);

	std::vector<RenderObject*> obj;

	RenderObject* ground = new RenderObject(groundShapes);
	ground->setTransform(glm::vec3(7.5f, 0.0f, 0.0f));

	RenderObject* wallet = new RenderObject(walletShapes);
	wallet->setRotation(glm::radians(-20.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	wallet->setTransform(glm::vec3(-5.0f, 0.0f, 4.5f));

	RenderObject* book = new RenderObject(bookShapes);
	book->setTransform(glm::vec3(0.0f, 0.1f, 2.0f));

	RenderObject* bottle = new RenderObject(bottleShapes);
	bottle->setTransform(glm::vec3(5.0f, 1.4f,-1.0f));

	RenderObject* pen = new RenderObject(penShapes);
	pen->setTransform(glm::vec3(3.5, 0.0f, 5.0f));
	pen->setRotation(glm::radians(-50.0f), glm::vec3(0.0f, 1.0f, 0.0f));

	RenderObject* pyr = new RenderObject(pyramidShapes);
	pyr->setTransform(glm::vec3(-4.0f, 0.0f, -4.0f));
	pyr->setRotation(glm::radians(45.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	pyr->setScale(glm::vec3(3.0f, 3.0f, 3.0f));

	obj.push_back(ground);
	obj.push_back(wallet);
	obj.push_back(book);
	obj.push_back(bottle);
	obj.push_back(pen);
	obj.push_back(pyr);

	Light* keyLight = new Light();
	keyLight->setTransform(glm::vec3(0.0f, 5.0f, 0.0f));
	keyLight->setColor(glm::vec3(1.0f, 1.0f, 0.8f));
	keyLight->setLightNum("1");
	keyLight->setSpecularIntensity(1.0f);
	
	Light* fillLight = new Light();
	fillLight->setTransform(glm::vec3(1.0f, 3.0f, 0.0f));
	fillLight->setColor(glm::vec3(1.0f, 1.0f, 0.0f));
	fillLight->setLightNum("2");
	fillLight->setSpecularIntensity(1.0f);

	lights = {
		keyLight,
		fillLight
	};

	Renderer renderer(obj, lights, vertexShaderSource, fragmentShaderSource, STPT::WIDTH, STPT::HEIGHT);

	float deltaTime = 0.0f, lastFrame = 0.0f;
	float specIncrement = 0.3f, highlightIncrement = 6.0f;

	// Render loop
	while (!glfwWindowShouldClose(window.getWindow()))
	{
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		camera.calculateOffset(deltaTime);
		// process the input
		window.processInput();
		// render the indices on screen
		renderer.Render(&window, &camera);
		// poll events
		window.pollEvents();
	}

	// when the window closes, exit
	exit(EXIT_SUCCESS);
}

std::string setTexture(std::string filename)
{
	return gTextureDir + filename;
}