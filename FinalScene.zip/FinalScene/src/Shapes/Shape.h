#pragma once
#include <iostream>
#include <glm/glm.hpp>
#include <GL/glew.h>
#include <src/Components/Texture.h>
#include <vector>

class Shape
{
protected:
	glm::vec3 transform;
	glm::vec3 rotation;
	glm::vec3 scale;
	float angle;
	GLushort* indices;
	GLfloat* vertices;
	int vertexCount;
	int indexCount;
	int vertexSize;
	int indexSize;
	std::vector<Texture*> textures;
	bool isTextured = false;
	bool isLit = false;
	bool isDynamic = false;
public:
	Shape(bool bIsTextured = true) : transform(glm::vec3(0)), rotation(glm::vec3(1.0, 0.0, 0.0)), scale(glm::vec3(1.0)), angle(0), indices(nullptr), vertices(nullptr), vertexSize(0), indexSize(0), isTextured(bIsTextured) {}
	Shape(bool bIsTextured, glm::vec3 transform, glm::vec3 rotation, glm::vec3 scale) : transform(transform), rotation(rotation), scale(scale), angle(0), indices(nullptr), vertices(nullptr), vertexSize(0), indexSize(0), isTextured(bIsTextured) {};
	~Shape() {}
	virtual void Initialize() {};
	bool multipleTextures() { return textures.size() > 1; }
	int getVerticesArraySize() { return vertexCount * vertexSize; }
	int getIndicesArraySize() { return indexCount * indexSize; }
	bool getIsLit() { return isLit; }
	void setIsLit(bool b) { isLit = b; }
	bool getIsDynamic() { return isDynamic; }
	void setIsDynamic(bool b) { isDynamic = b; }
	GLfloat* getVertices() { return vertices; }
	GLushort* getIndices() { return indices; }
	glm::vec3 getTransform() { return transform; }
	glm::vec3 getRotation() { return rotation; }
	glm::vec3 getScale() { return scale; }
	int getVertexCount() { return vertexCount; }
	int getIndexCount() { return indexCount; }
	int getVertexSize() { return vertexSize; }
	int getIndexSize() { return indexSize; }
	float getAngle() { return angle; }
	float getTransformX() { return transform.x; }
	float getTransformY() { return transform.y; }
	float getTransformZ() { return transform.z; }
	float getRotationX() { return rotation.x; }
	float getRotationY() { return rotation.y; }
	float getRotationZ() { return rotation.z; }
	float getScaleX() { return scale.x; }
	float getScaleY() { return scale.y; }
	float getScaleZ() { return scale.z; }
	bool IsTextured() { return isTextured; }
	std::vector<Texture*> getTexture() { return textures; }
	void setAngle(float w) { angle = w; }
	void setTransformX(float x) { transform.x = x; }
	void setTransformY(float y) { transform.y = y; }
	void setTransformZ(float z) { transform.z = z; }
	void setRotationX(float x) { rotation.x = x; }
	void setRotationY(float y) { rotation.y = y; }
	void setRotationZ(float z) { rotation.z = z; }
	void setScaleX(float x) { scale.x = x; }
	void setScaleY(float y) { scale.y = y; }
	void setScaleZ(float z) { scale.z = z; }
	void setScale(glm::vec3 s) { scale = s; }
	void setRotation(float a, glm::vec3 r) { angle = a; rotation = r; }
	void setTransform(glm::vec3 t) { transform = t; }
};

