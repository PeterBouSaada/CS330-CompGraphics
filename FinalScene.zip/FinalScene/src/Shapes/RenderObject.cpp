#include "RenderObject.h"

RenderObject::RenderObject(std::vector<Shape*> s)
{
	this->shapes = s;
}

void RenderObject::setShapes(std::vector<Shape*> s)
{
	shapes = s;
}

void RenderObject::addShape(Shape* shape)
{
	shapes.push_back(shape);
}

void RenderObject::removeShape(Shape* shape)
{
	shapes.erase(std::remove(shapes.begin(), shapes.end(), shape), shapes.end());
}
