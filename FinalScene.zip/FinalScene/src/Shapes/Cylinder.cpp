#include "Cylinder.h"

Cylinder::Cylinder(int sectorCount, std::vector<Texture*> tex) : Shape(tex.size() > 0)
{
	isTextured = tex.size() > 0;
	textures = tex;
	m_SectorCount = sectorCount;
	Initialize();
}

Cylinder::Cylinder(glm::vec3 transform, glm::vec3 rotation, glm::vec3 scale, std::vector<Texture*> tex) : Shape(tex.size() > 0, transform, rotation, scale)
{
	isTextured = tex.size() > 0;
	textures = tex;
	this->transform = transform;
	this->rotation = rotation;
	this->scale = scale;
	Initialize();
}

void Cylinder::Initialize()
{

	/*
		This code is heavily inspired from:
		http://www.songho.ca/opengl/gl_cylinder.html
	*/

	std::vector<float> unitVertices;
	const float PI = 3.1415926f;
	float sectorStep = 2 * PI / m_SectorCount;
	float sectorAngle;

	std::vector<float> unitCircleVertices;
	for (int i = 0; i <= m_SectorCount; ++i)
	{
		sectorAngle = i * sectorStep;
		unitCircleVertices.push_back(cos(sectorAngle)); 
		unitCircleVertices.push_back(sin(sectorAngle)); 
		unitCircleVertices.push_back(0);                
	}
	unitVertices = unitCircleVertices;

	std::vector<float> verts;
	std::vector<float> norms;
	std::vector<float> texCoords;

	float height = 1.0f;
	float radius = 0.5f;

	for (int i = 0; i < 2; ++i)
	{
		float h = -height / 2.0f + i * height;         
		float t = 1.0f - i;                            

		for (int j = 0, k = 0; j <= m_SectorCount; ++j, k += 3)
		{
			float ux = unitVertices[k];
			float uy = unitVertices[k + 1];
			float uz = unitVertices[k + 2];
			// position vector
			verts.push_back(ux * radius);            
			verts.push_back(uy * radius);            
			verts.push_back(h);                      
			// normal vector
			norms.push_back(ux);                     
			norms.push_back(uy);                     
			norms.push_back(uz);                     
			// texture coordinate
			texCoords.push_back((float)j / m_SectorCount);
			texCoords.push_back(t);
		}
	}

	int baseCenterIndex = (int)verts.size() / 3;
	int topCenterIndex = baseCenterIndex + m_SectorCount + 1;

	for (int i = 0; i < 2; ++i)
	{
		float h = -height / 2.0f + i * height;
		float nz = -1 + i * 2;                

		verts.push_back(0);     verts.push_back(0);     verts.push_back(h);
		norms.push_back(0);      norms.push_back(0);      norms.push_back(nz);
		texCoords.push_back(0.5f); texCoords.push_back(0.5f);

		for (int j = 0, k = 0; j < m_SectorCount; ++j, k += 3)
		{
			float ux = unitVertices[k];
			float uy = unitVertices[k + 1];
			// position vector
			verts.push_back(ux * radius);          
			verts.push_back(uy * radius);          
			verts.push_back(h);                    
			// normal vector
			norms.push_back(0);                    
			norms.push_back(0);                    
			norms.push_back(nz);                   
			// texture coordinate
			texCoords.push_back(-ux * 0.5f + 0.5f);
			texCoords.push_back(-uy * 0.5f + 0.5f);
		}
	}

	int totalSize = verts.size() + norms.size() + texCoords.size() + ((verts.size() / 3.0f) * 4);
	vertices = new GLfloat;
	vertices = (float*)calloc(totalSize, sizeof(float));

	for (int i = 0; i < totalSize; i += 12)
	{
		// add position
		vertices[i] = verts.front();
		verts.erase(verts.begin());
		vertices[i + 1] = verts.front();
		verts.erase(verts.begin());
		vertices[i + 2] = verts.front();
		verts.erase(verts.begin());
		// add color
		vertices[i + 3] = 0.0f;
		vertices[i + 4] = 0.0f;
		vertices[i + 5] = 0.0f;
		vertices[i + 6] = 0.0f;
		// add texture coords
		vertices[i + 7] = texCoords.front();
		texCoords.erase(texCoords.begin());
		vertices[i + 8] = texCoords.front();
		texCoords.erase(texCoords.begin());
		// add normals
		vertices[i + 9] = norms.front();
		norms.erase(norms.begin());
		vertices[i + 10] = norms.front();
		norms.erase(norms.begin());
		vertices[i + 11] = norms.front();
		norms.erase(norms.begin());
	}

	vertexCount = totalSize / 12.0f;
	vertexSize = 12;

	std::vector<int> inds;
	int k1 = 0;
	int k2 = m_SectorCount + 1;

	for (int i = 0; i < m_SectorCount; ++i, ++k1, ++k2)
	{
		inds.push_back(k1);
		inds.push_back(k1 + 1);
		inds.push_back(k2);

		inds.push_back(k2);
		inds.push_back(k1 + 1);
		inds.push_back(k2 + 1);
	}

	for (int i = 0, k = baseCenterIndex + 1; i < m_SectorCount; ++i, ++k)
	{
		if (i < m_SectorCount - 1)
		{
			inds.push_back(baseCenterIndex);
			inds.push_back(k + 1);
			inds.push_back(k);
		}
		else
		{
			inds.push_back(baseCenterIndex);
			inds.push_back(baseCenterIndex + 1);
			inds.push_back(k);
		}
	}

	for (int i = 0, k = topCenterIndex + 1; i < m_SectorCount; ++i, ++k)
	{
		if (i < m_SectorCount - 1)
		{
			inds.push_back(topCenterIndex);
			inds.push_back(k);
			inds.push_back(k + 1);
		}
		else
		{
			inds.push_back(topCenterIndex);
			inds.push_back(k);
			inds.push_back(topCenterIndex + 1);
		}
	}

	int totalindsSize = inds.size();
	indices = (unsigned short*)calloc(totalindsSize, sizeof(unsigned short));

	for (int i = 0; i < totalindsSize; i++)
	{
		indices[i] = inds.front();
		inds.erase(inds.begin());
	}

	indexCount = totalindsSize / 3.0f;
	indexSize = 3.0f;

}
