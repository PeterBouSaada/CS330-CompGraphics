#pragma once
#include "Shape.h"


class Cube: public Shape
{
private:
	static GLfloat defaultVertices[72];
	static GLushort defaultIndices[36];
	static GLfloat texturedVertices[24 * 12];
	static GLushort texturedIndices[36];
public:
	Cube(std::vector<Texture*> tex = std::vector<Texture*>(0));
	Cube(glm::vec3 transform, glm::vec3 rotation, glm::vec3 scale, std::vector<Texture*> tex = std::vector<Texture*>(0));
	~Cube() {};
	void Initialize() override;
};

