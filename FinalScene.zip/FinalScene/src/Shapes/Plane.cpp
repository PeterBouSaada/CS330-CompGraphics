#include "Plane.h"

GLfloat Plane::defaultVertices[] = {
   -0.5f,  1.0f,  0.0f,		1.0f, 1.0f, 1.0f, 0.0f,		0.0f, 1.0f, // 0 - top left
	0.5f,  1.0f,  0.0f,		0.0f, 1.0f, 0.0f, 0.0f,		1.0f, 1.0f, // 1 - top right
   -0.5f,  0.0f,  0.0f,		0.0f, 0.0f, 1.0f, 0.0f,		0.0f, 0.0f, // 2 - bottom left
	0.5f,  0.0f, -0.0f,		1.0f, 0.0f, 0.0f, 0.0f,		1.0f, 0.0f  // 3 - bottom right
};

GLushort Plane::defaultIndices[] = {
	0, 1, 2,
	2, 1, 3
};

GLfloat Plane::texturedVertices[] = {
	// Space Coordinates	// Color coords				// UV Coordinates	// normals
   -0.5f,  1.0f,  0.0f,		0.0f, 0.0f, 0.0f, 0.0f,		0.0f, 1.0f,			0.0f,0.0f,1.0f, // 0 - top left
	0.5f,  1.0f,  0.0f,		0.0f, 0.0f, 0.0f, 0.0f,		1.0f, 1.0f,			0.0f,0.0f,1.0f, // 1 - top right
   -0.5f,  0.0f,  0.0f,		0.0f, 0.0f, 0.0f, 0.0f,		0.0f, 0.0f,			0.0f,0.0f,1.0f, // 2 - bottom left
	0.5f,  0.0f, -0.0f,		0.0f, 0.0f, 0.0f, 0.0f,		1.0f, 0.0f,			0.0f,0.0f,1.0f// 3 - bottom right
};

GLushort Plane::texturedIndices[] = {
	0, 1, 2,
	2, 1, 3
};

Plane::Plane(std::vector<Texture*> tex) : Shape(tex.size() > 0)
{
	isTextured = tex.size() > 0;
	textures = tex;
	Initialize();
}

Plane::Plane(glm::vec3 transform, glm::vec3 rotation, glm::vec3 scale, std::vector<Texture*> tex) : Shape(tex.size() > 0, transform, rotation, scale)
{
	isTextured = tex.size() > 0;
	textures = tex;
	this->transform = transform;
	this->rotation = rotation;
	this->scale = scale;
	Initialize();
}

void Plane::Initialize()
{
	if (isTextured)
	{
		vertexCount = 4;
		indexCount = 2;
		vertexSize = 12;
		indexSize = 3;
		vertices = texturedVertices;
		indices = texturedIndices;
	}
	else
	{
		vertexCount = 4;
		indexCount = 2;
		vertexSize = 9;
		indexSize = 3;
		vertices = defaultVertices;
		indices = defaultIndices;
	}
}
