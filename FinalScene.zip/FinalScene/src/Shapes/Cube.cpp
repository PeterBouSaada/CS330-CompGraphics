#include "Cube.h"
#include <iostream>

GLfloat Cube::defaultVertices[] = {
   -0.5f,  1.0f,  0.5f,		1.0f, 0.0f, 0.0f, 0.0f,     0.0f, 0.0f, // 0 - front-top left
	0.5f,  1.0f,  0.5f,		0.0f, 1.0f, 0.0f, 0.0f,     0.0f, 0.0f, // 1 - front-top right
   -0.5f,  0.0f,  0.5f,		0.0f, 0.0f, 1.0f, 0.0f,     0.0f, 0.0f, // 2 - front-bottom left
	0.5f,  0.0f,  0.5f,		1.0f, 0.0f, 0.0f, 0.0f,     0.0f, 0.0f, // 3 - front-bottom right
   -0.5f,  1.0f, -0.5f,		0.0f, 1.0f, 0.0f, 0.0f,     0.0f, 0.0f, // 4 - back-top left
	0.5f,  1.0f, -0.5f,		0.0f, 0.0f, 1.0f, 0.0f,     0.0f, 0.0f, // 5 - back-top right
   -0.5f,  0.0f, -0.5f,		1.0f, 0.0f, 0.0f, 0.0f,     0.0f, 0.0f, // 6 - back-bottom left
	0.5f,  0.0f, -0.5f,		0.0f, 1.0f, 0.0f, 0.0f,     0.0f, 0.0f, // 7 - back-bottom right
};

GLushort Cube::defaultIndices[] = {
	1, 0, 2, 2, 3, 1,	//front face
	5, 1, 3, 3, 7, 5,	// right face
	4, 5, 7, 7, 6, 4,	// back face
	0, 4, 6, 6, 2, 0,	// left face
	5, 4, 0, 0, 1, 5,	// top face
	7, 6, 2, 2, 3, 7	// bottom face
};

GLfloat Cube::texturedVertices[]{

	 0.5f,  0.5f,  0.5f,    0.0f, 0.0f, 0.0f, 0.0f,     1.f, 1.f,	0.0f, 0.0f ,0.0f,
	 0.5f, -0.5f,  0.5f,    0.0f, 0.0f, 0.0f, 0.0f,     1.f, 0.f,	0.0f, 0.0f ,0.0f,
	-0.5f, -0.5f,  0.5f,    0.0f, 0.0f, 0.0f, 0.0f,     0.f, 0.f,	0.0f, 0.0f ,0.0f,
	-0.5f,  0.5f,  0.5f,    0.0f, 0.0f, 0.0f, 0.0f,     0.f, 1.f,	0.0f, 0.0f ,0.0f,
	-0.5f,  0.5f, -0.5f,    0.0f, 0.0f, 0.0f, 0.0f,     1.f, 1.f,	0.0f, 0.0f ,0.0f,
	-0.5f, -0.5f, -0.5f,    0.0f, 0.0f, 0.0f, 0.0f,     1.f, 0.f,	0.0f, 0.0f ,0.0f,
	 0.5f, -0.5f, -0.5f,    0.0f, 0.0f, 0.0f, 0.0f,     0.f, 0.f,	0.0f, 0.0f ,0.0f,
	 0.5f,  0.5f, -0.5f,    0.0f, 0.0f, 0.0f, 0.0f,     0.f, 1.f,	0.0f, 0.0f ,0.0f,
	-0.5f,	0.5f,  0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		1.f, 1.f,	0.0f, 0.0f ,0.0f,
	-0.5f, -0.5f,  0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		1.f, 0.f,	0.0f, 0.0f ,0.0f,
	-0.5f, -0.5f, -0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		0.f, 0.f,	0.0f, 0.0f ,0.0f,
	-0.5f,	0.5f, -0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		0.f, 1.f,	0.0f, 0.0f ,0.0f,
	 0.5f,  0.5f, -0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		1.f, 1.f,	0.0f, 0.0f ,0.0f,
	 0.5f, -0.5f, -0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		1.f, 0.f,	0.0f, 0.0f ,0.0f,
	 0.5f, -0.5f,  0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		0.f, 0.f,	0.0f, 0.0f ,0.0f,
	 0.5f,  0.5f,  0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		0.f, 1.f,	0.0f, 0.0f ,0.0f,
	 0.5f,  0.5f, -0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		1.f, 1.f,	0.0f, 0.0f ,0.0f,
	 0.5f,  0.5f,  0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		1.f, 0.f,	0.0f, 0.0f ,0.0f,
	-0.5f,  0.5f,  0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		0.f, 0.f,	0.0f, 0.0f ,0.0f,
	-0.5f,  0.5f, -0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		0.f, 1.f,	0.0f, 0.0f ,0.0f,
	 0.5f, -0.5f,  0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		1.f, 1.f,	0.0f, 0.0f ,0.0f,
	 0.5f, -0.5f, -0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		1.f, 0.f,	0.0f, 0.0f ,0.0f,
	-0.5f, -0.5f, -0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		0.f, 0.f,	0.0f, 0.0f ,0.0f,
	-0.5f, -0.5f,  0.5f,    0.0f, 0.0f, 0.0f, 0.0f,		0.f, 1.f,	0.0f, 0.0f ,0.0f
};

GLushort Cube::texturedIndices[]{
	0, 1, 3,
	1, 2, 3,
	4, 5, 7,
	5, 6, 7,
	8, 9, 11,
	9, 10, 11,
	12, 13, 15,
	13, 14, 15,
	16, 17, 19,
	17, 18, 19,
	20, 21, 23,
	21, 22, 23,
};

Cube::Cube(std::vector<Texture*> tex) : Shape(tex.size() > 0)
{
	isTextured = tex.size() > 0;
	textures = tex;
	Initialize();
}

Cube::Cube(glm::vec3 transform, glm::vec3 rotation, glm::vec3 scale, std::vector<Texture*> tex) : Shape(tex.size() > 0, transform, rotation, scale)
{
	isTextured = tex.size() > 0;
	textures = tex;
	this->transform = transform;
	this->rotation = rotation;
	this->scale = scale;
	Initialize();
}

void Cube::Initialize()
{

	if (isTextured)
	{
		vertexCount = 24;
		indexCount = 12;
		vertexSize = 12;
		indexSize = 3;
		vertices = texturedVertices;
		indices = texturedIndices;
	}
	else
	{
		vertexCount = 8;
		indexCount = 12;
		vertexSize = 9;
		indexSize = 3;
		vertices = defaultVertices;
		indices = defaultIndices;
	}
}
