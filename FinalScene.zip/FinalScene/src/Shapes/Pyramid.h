#pragma once
#include "Shape.h"
#include <src/Components/Texture.h>

class Pyramid : public Shape
{
private:
	static GLfloat defaultVertices[45];
	static GLushort defaultIndices[18];
	static GLfloat texturedVertices[12 * 16];
	static GLushort texturedIndices[6 * 3];
public:
	Pyramid(std::vector<Texture*> tex = std::vector<Texture*>(0));
	Pyramid(glm::vec3 transform, glm::vec3 rotation, glm::vec3 scale, std::vector<Texture*> tex = std::vector<Texture*>(0));
	~Pyramid() {};
	void Initialize() override;
};

