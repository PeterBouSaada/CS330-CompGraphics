#pragma once
#include "Shape.h"
#include "../Math/ModelMatrix.h"
#include "../Components/VertexArray.h"
#include "../Components/VertexBuffer.h"
#include "../Components/IndexBuffer.h"
#include <vector>

class RenderObject : public Shape
{
private:
	VertexArray* vao = nullptr;
	VertexBuffer* vbo = nullptr;
	IndexBuffer* ibo = nullptr;
	std::vector<Shape*> shapes;
public:
	RenderObject(std::vector<Shape*> s);
	~RenderObject() {};
	void setShapes(std::vector<Shape*> s);
	std::vector<Shape*> getShapes() { return shapes; }
	void addShape(Shape* shape);
	void removeShape(Shape* shape);
	void setVAO(VertexArray* val) { vao = val; }
	VertexArray* getVAO() { return vao; }
	void setVBO(VertexBuffer* val) { vbo = val; }
	VertexBuffer* getVBO() { return vbo; }
	void setIBO(IndexBuffer* val) { ibo = val; }
	IndexBuffer* getIBO() { return ibo; }
};

