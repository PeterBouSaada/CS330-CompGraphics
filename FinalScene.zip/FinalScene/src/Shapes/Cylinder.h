#pragma once
#include <src/Shapes/Shape.h>

class Cylinder : public Shape
{
private:
	int m_SectorCount = 3;
public:
	Cylinder(int sectorCount, std::vector<Texture*> tex = std::vector<Texture*>(0));
	Cylinder(glm::vec3 transform, glm::vec3 rotation, glm::vec3 scale, std::vector<Texture*> tex = std::vector<Texture*>(0));
	~Cylinder() {};
	void Initialize() override;
};

