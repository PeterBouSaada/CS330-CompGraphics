#pragma once
#include "Shape.h"

class Plane : public Shape
{
private:
	static GLfloat defaultVertices[36];
	static GLushort defaultIndices[6];
	static GLfloat texturedVertices[4 * 12];
	static GLushort texturedIndices[6];
	bool isLit = true;
public:
	Plane(std::vector<Texture*> tex = std::vector<Texture*>(0));
	Plane(glm::vec3 transform, glm::vec3 rotation, glm::vec3 scale, std::vector<Texture*> tex = std::vector<Texture*>(0));
	~Plane() {};
	void Initialize() override;
};

