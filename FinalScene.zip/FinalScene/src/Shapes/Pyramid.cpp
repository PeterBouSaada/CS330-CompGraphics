#include "Pyramid.h"

GLfloat Pyramid::defaultVertices[] = {
	0.0f,  1.0f,  0.0f,		1.0f, 1.0f, 1.0f, 0.0f,		0.0f, 0.0f,  // 0 - top
	0.5f,  0.0f,  0.5f,		0.0f, 1.0f, 0.0f, 0.0f,		0.0f, 0.0f,  // 1 - front right
   -0.5f,  0.0f,  0.5f,		0.0f, 0.0f, 1.0f, 0.0f,		0.0f, 0.0f,  // 2 - front left
	0.5f,  0.0f, -0.5f,		1.0f, 0.0f, 0.0f, 0.0f,		0.0f, 0.0f,  // 3 - back right
   -0.5f,  0.0f, -0.5f,		0.0f, 1.0f, 0.0f, 0.0f,		0.0f, 0.0f   // 4 - back left
};

GLushort Pyramid::defaultIndices[] = {
	0, 1, 2,	// front face
	0, 3, 1,	// right face
	0, 4, 3,	// back face
	0, 2, 4,	// left face
	1, 3, 4,	// back bottom face
	4, 2, 1		// front bottom face
};

GLfloat Pyramid::texturedVertices[] = {
	// Space Coordinates	// Color coords				// UV Coordinates	// normals
	// front face
	0.0f,  1.0f,  0.0f,		0.0f, 0.0f, 0.0f, 1.0f,		0.5f, 1.0f,			0.0f, 0.0f, 1.0f, // 0 - top
   -0.5f,  0.0f,  0.5f,		0.0f, 0.0f, 0.0f, 1.0f,		0.0f, 0.0f,			0.0f, 0.0f, 1.0f, // 1 - front left
	0.5f,  0.0f,  0.5f,		0.0f, 0.0f, 0.0f, 1.0f,		1.0f, 0.0f,			0.0f, 0.0f, 1.0f, // 2 - front right
	
	// right face
	0.0f,  1.0f,  0.0f,		0.0f, 0.0f, 0.0f, 1.0f,		0.5f, 1.0f,			1.0f, 0.0f, 0.0f, // 3 - top
	0.5f,  0.0f,  0.5f,		0.0f, 0.0f, 0.0f, 1.0f,		0.0f, 0.0f,			1.0f, 0.0f, 0.0f, // 4 - front right
	0.5f,  0.0f, -0.5f,		0.0f, 0.0f, 0.0f, 1.0f,		1.0f, 0.0f,			1.0f, 0.0f, 0.0f, // 5 - back right

	// back face
	0.0f,  1.0f,  0.0f,		0.0f, 0.0f, 0.0f, 1.0f,		0.5f, 1.0f,			0.0f, 0.0f, -1.0f, // 6 - top
	0.5f,  0.0f, -0.5f,		0.0f, 0.0f, 0.0f, 1.0f,		0.0f, 0.0f,			0.0f, 0.0f, -1.0f, // 7 - back right
   -0.5f,  0.0f, -0.5f,		0.0f, 0.0f, 0.0f, 1.0f,		1.0f, 0.0f,			0.0f, 0.0f, -1.0f, // 8 - back left

   // left face
	0.0f,  1.0f,  0.0f,		0.0f, 0.0f, 0.0f, 1.0f,		0.5f, 1.0f,			-1.0f, 0.0f, 0.0f, // 9 - top
   -0.5f,  0.0f, -0.5f,		0.0f, 0.0f, 0.0f, 1.0f,		0.0f, 0.0f,			-1.0f, 0.0f, 0.0f, // 10 - back left
   -0.5f,  0.0f,  0.5f,		0.0f, 0.0f, 0.0f, 1.0f,		1.0f, 0.0f,			-1.0f, 0.0f, 0.0f, // 11 - front left

   //bottom face
   -0.5f,  0.0f, -0.5f,		0.0f, 0.0f, 0.0f, 1.0f,		0.0f, 0.0f,			0.0f, -1.0f, 0.0f, // 12 - back left
	0.5f,  0.0f, -0.5f,		0.0f, 0.0f, 0.0f, 1.0f,		1.0f, 0.0f,			0.0f, -1.0f, 0.0f, // 13 - back right
	0.5f,  0.0f,  0.5f,		0.0f, 0.0f, 0.0f, 1.0f,		1.0f, 1.0f,			0.0f, -1.0f, 0.0f, // 14 - front right
   -0.5f,  0.0f,  0.5f,		0.0f, 0.0f, 0.0f, 1.0f,		0.0f, 1.0f,			0.0f, -1.0f, 0.0f, // 15 - front left

};

GLushort Pyramid::texturedIndices[] = {
	0,	 1,  2,
	3,	 4,  5,
	6,	 7,  8,
	9,	10, 11,
	12, 13, 14,
	14, 15, 12
};

Pyramid::Pyramid(std::vector<Texture*> tex) : Shape(tex.size() > 0)
{
	isTextured = tex.size() > 0;
	textures = tex;
	Initialize();
}

Pyramid::Pyramid(glm::vec3 transform, glm::vec3 rotation, glm::vec3 scale, std::vector<Texture*> tex) : Shape(tex.size() > 0, transform, rotation, scale)
{
	isTextured = tex.size() > 0;
	textures = tex;
	this->transform = transform;
	this->rotation = rotation;
	this->scale = scale;
	Initialize();
}

void Pyramid::Initialize()
{
	if(isTextured)
	{ 
		vertexCount = 16;
		vertexSize = 12;
		indexCount = 6;
		indexSize = 3;
		vertices = texturedVertices;
		indices = texturedIndices;
	}
	else
	{
		vertexCount = 5;
		vertexSize = 9;
		indexCount = 6;
		indexSize = 3;
		vertices = defaultVertices;
		indices = defaultIndices;
	}
	
}
